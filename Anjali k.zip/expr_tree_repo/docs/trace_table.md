# Trace Tables

**Postfix expression:** `8 3 2 * + 6 2 / -`

## 1) Stack-based postfix evaluation — trace

| Step | Token | Action | Stack after step |
|---|---|---|---|
| 1 | 8 | push | 8 |
| 2 | 3 | push | 8, 3 |
| 3 | 2 | push | 8, 3, 2 |
| 4 | * | pop 3,2 → 3*2=6, push | 8, 6 |
| 5 | + | pop 8,6 → 8+6=14, push | 14 |
| 6 | 6 | push | 14, 6 |
| 7 | 2 | push | 14, 6, 2 |
| 8 | / | pop 6,2 → 6/2=3, push | 14, 3 |
| 9 | - | pop 14,3 → 14-3=11, push | 11 |

**Result = 11**

## 2) Expression tree evaluation — trace (post-order recursion)

| Step | Node visited | Operation | Result |
|---|---|---|---|
| 1 | `*` | 3 * 2 | 6 |
| 2 | `+` | 8 + 6 | 14 |
| 3 | `/` | 6 / 2 | 3 |
| 4 | `-` | 14 - 3 | 11 |

**Result = 11**

Both methods agree: **11**
