/*
 * Question 4: Postfix expression -> 8 3 2 * + 6 2 / -
 * a) Build an Expression Tree from the postfix expression. Display tree traversals.
 * b) Evaluate the expression using:
 *      - Stack-based postfix evaluation
 *      - Expression Tree evaluation
 *    with a trace of intermediate operations for both.
 * c) Compare the two approaches (ops count, data structure, time, space).
 *
 * Compile: gcc expression_tree.c -o expression_tree
 * Run:     ./expression_tree
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX 100

/* ---------- Expression Tree Node ---------- */
typedef struct Node {
    char data;
    struct Node *left, *right;
} Node;

Node* newNode(char data) {
    Node* n = (Node*)malloc(sizeof(Node));
    n->data = data;
    n->left = n->right = NULL;
    return n;
}

int isOperator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/');
}

/* ---------- Stack of Node* (used to build the expression tree) ---------- */
Node* nodeStack[MAX];
int nodeTop = -1;

void nodePush(Node* n) { nodeStack[++nodeTop] = n; }
Node* nodePop(void) { return nodeStack[nodeTop--]; }

/* ---------- Stack of int (used for stack-based postfix evaluation) ---------- */
int valStack[MAX];
int valTop = -1;

void valPush(int v) { valStack[++valTop] = v; }
int valPop(void) { return valStack[valTop--]; }

int applyOp(int a, int b, char op) {
    switch (op) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': return a / b;
    }
    return 0;
}

/* ---------- a) Build Expression Tree from postfix tokens ---------- */
Node* buildExpressionTree(char tokens[][10], int n) {
    nodeTop = -1;
    for (int i = 0; i < n; i++) {
        char *tok = tokens[i];
        if (!isOperator(tok[0]) || tok[1] != '\0') {
            /* operand (single digit, per this assignment's input) */
            Node* leaf = newNode(tok[0]);
            nodePush(leaf);
        } else {
            Node* right = nodePop();
            Node* left  = nodePop();
            Node* opNode = newNode(tok[0]);
            opNode->left = left;
            opNode->right = right;
            nodePush(opNode);
        }
    }
    return nodePop();
}

/* helper: get integer value of a leaf (single-digit operand) */
int leafValue(Node* n) { return n->data - '0'; }

/* ---------- Traversals ---------- */
void inorder(Node* root) {
    if (!root) return;
    if (root->left || root->right) printf("(");
    inorder(root->left);
    printf("%c", root->data);
    inorder(root->right);
    if (root->left || root->right) printf(")");
}

void preorder(Node* root) {
    if (!root) return;
    printf("%c ", root->data);
    preorder(root->left);
    preorder(root->right);
}

void postorder(Node* root) {
    if (!root) return;
    postorder(root->left);
    postorder(root->right);
    printf("%c ", root->data);
}

/* ---------- b) Expression Tree evaluation (post-order, recursive) with trace ---------- */
int evalTreeTrace(Node* root, int* step) {
    if (!root) return 0;
    if (!root->left && !root->right) {
        return leafValue(root);
    }
    int leftVal  = evalTreeTrace(root->left, step);
    int rightVal = evalTreeTrace(root->right, step);
    int result = applyOp(leftVal, rightVal, root->data);
    (*step)++;
    printf("  Step %d: node '%c'  ->  %d %c %d = %d\n",
           *step, root->data, leftVal, root->data, rightVal, result);
    return result;
}

/* ---------- b) Stack-based postfix evaluation with trace ---------- */
int stackEvaluate(char tokens[][10], int n) {
    valTop = -1;
    int step = 0;
    for (int i = 0; i < n; i++) {
        char *tok = tokens[i];
        if (!isOperator(tok[0]) || tok[1] != '\0') {
            int v = atoi(tok);
            valPush(v);
            printf("  Step %-2d: push operand %-2d           -> stack: ", ++step, v);
            for (int k = 0; k <= valTop; k++) printf("%d ", valStack[k]);
            printf("\n");
        } else {
            int b = valPop();
            int a = valPop();
            int result = applyOp(a, b, tok[0]);
            valPush(result);
            printf("  Step %-2d: %d %c %d = %-3d (pop 2, push) -> stack: ",
                   ++step, a, tok[0], b, result);
            for (int k = 0; k <= valTop; k++) printf("%d ", valStack[k]);
            printf("\n");
        }
    }
    return valPop();
}

int main(void) {
    /* Input: postfix tokens for  8 3 2 * + 6 2 / -  */
    char tokens[][10] = {"8", "3", "2", "*", "+", "6", "2", "/", "-"};
    int n = sizeof(tokens) / sizeof(tokens[0]);

    printf("Input postfix expression: 8 3 2 * + 6 2 / -\n\n");

    /* a) Build expression tree */
    Node* root = buildExpressionTree(tokens, n);

    printf("=== a) Expression Tree Traversals ===\n");
    printf("Inorder   (with parentheses): ");
    inorder(root);
    printf("\n");
    printf("Preorder  : ");
    preorder(root);
    printf("\n");
    printf("Postorder : ");
    postorder(root);
    printf("\n\n");

    /* b) Stack-based postfix evaluation */
    printf("=== b1) Stack-based Postfix Evaluation Trace ===\n");
    int stackResult = stackEvaluate(tokens, n);
    printf("Stack-based evaluation result = %d\n\n", stackResult);

    /* b) Expression tree evaluation */
    printf("=== b2) Expression Tree Evaluation Trace (post-order) ===\n");
    int step = 0;
    int treeResult = evalTreeTrace(root, &step);
    printf("Expression Tree evaluation result = %d\n\n", treeResult);

    printf("Both methods agree: %s\n", (stackResult == treeResult) ? "YES" : "NO");

    return 0;
}
