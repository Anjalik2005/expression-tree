# Complexity Analysis

Let **n** = number of tokens in the postfix expression.

## Stack-based postfix evaluation
- Each token is processed exactly once: operand → push (O(1)); operator → pop two, compute, push (O(1)).
- **Time complexity:** O(n)
- **Space complexity:** O(n) worst case — the value stack can hold up to ⌈n/2⌉ operands before any operator appears.

## Expression tree approach
- **Construction:** each token processed once — push a leaf node, or pop two nodes/link/push one operator node. O(1) work per token.
  - Construction time: O(n)
- **Evaluation:** a full post-order traversal visits every node exactly once.
  - Evaluation time: O(n)
- **Total time complexity:** O(n) (construction) + O(n) (evaluation) = **O(n)**
- **Space complexity:**
  - O(n) to store the n tree nodes.
  - O(h) additional recursion-stack space during evaluation, where h is the tree height.
    - Balanced tree: h = O(log n)
    - Skewed/degenerate tree: h = O(n)

## Summary

| Approach | Time | Space |
|---|---|---|
| Stack-based postfix evaluation | O(n) | O(n) |
| Expression tree (build) | O(n) | O(n) |
| Expression tree (evaluate) | O(n) | O(h), h ≤ n |

Both approaches are linear in the number of tokens. The expression tree has the same asymptotic complexity but a larger constant factor (node allocation, pointer chasing, recursion) and additional persistent memory for the tree structure.
