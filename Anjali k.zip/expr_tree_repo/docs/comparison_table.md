# Comparison: Stack-based Postfix Evaluation vs Expression Tree Evaluation

| Criterion | Stack-based Postfix Eval | Expression Tree Eval |
|---|---|---|
| Number of operations | 9 token scans, 4 pop-pairs/apply calls | 9 nodes built once, then 4 recursive apply calls during evaluation |
| Data structure used | One 1-D array/stack of `int` | Binary tree of nodes (left/right pointers) + a temporary node-stack during construction |
| Time complexity | O(n) — single left-to-right scan | O(n) to build + O(n) to evaluate = O(n) overall |
| Space complexity | O(n) worst case (stack depth) | O(n) for tree nodes + O(h) recursion stack (h = tree height) |
| Re-evaluation | Must re-scan and recompute from scratch every time | Tree persists; can be re-evaluated or traversed differently without rebuilding |
| Extra structural info | None — only the final numeric answer is available | Full expression structure (precedence, sub-expressions, infix/prefix form) is recoverable |
| Best suited for | Simple calculators, one-shot evaluation | Compilers, symbolic algebra, expression optimization, anything needing the expression's structure |
