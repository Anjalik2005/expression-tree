# Expression Tree vs Stack-Based Postfix Evaluation

**Postfix expression:** `8 3 2 * + 6 2 / -`

This repo contains everything required by the assignment:

| Requirement | File |
|---|---|
| Source code | [`src/expression_tree.c`](src/expression_tree.c) |
| Input data | [`input/input.txt`](input/input.txt) |
| Output | [`output/output.txt`](output/output.txt) |
| Trace table | [`docs/trace_table.md`](docs/trace_table.md) |
| Complexity analysis | [`docs/complexity_analysis.md`](docs/complexity_analysis.md) |
| Comparison table | [`docs/comparison_table.md`](docs/comparison_table.md) |
| Final conclusion | [`docs/conclusion.md`](docs/conclusion.md) |

## What the program does
1. Builds an **Expression Tree** from the postfix expression and prints its inorder,
   preorder, and postorder traversals.
2. Evaluates the expression two ways, with a step-by-step trace for each:
   - Stack-based postfix evaluation
   - Expression tree evaluation (post-order recursion)
3. Confirms both methods agree on the result: **11**

## How to run
```bash
cd src
gcc expression_tree.c -o expression_tree
./expression_tree
```

## Folder structure
```
.
├── src/
│   └── expression_tree.c
├── input/
│   └── input.txt
├── output/
│   └── output.txt
├── docs/
│   ├── trace_table.md
│   ├── complexity_analysis.md
│   ├── comparison_table.md
│   └── conclusion.md
└── README.md
```
